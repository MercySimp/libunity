#!/usr/bin/python

from gi.repository import UnityExtras

player = UnityExtras.PreviewPlayer.new ()
