dbus-monitor "type='signal',sender='org.mpris.MediaPlayer2.rhythmbox',interface='org.freedesktop.DBus.Properties'"

